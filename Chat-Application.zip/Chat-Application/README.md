## We have try our best to complete this project.

## This is a real time chat application.

<br/>
<p>We have added all common functionality in our chat application </p>
