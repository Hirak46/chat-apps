// get login page
function getLogin(req, res, next) {
  res.render("index");
}

module.exports = {
  getLogin,
};
